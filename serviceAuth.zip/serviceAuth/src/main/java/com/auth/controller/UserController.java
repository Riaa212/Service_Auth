package com.auth.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.auth.domain.EmailDetails;
import com.auth.domain.LoginRequest;
import com.auth.domain.LoginResponse;
import com.auth.domain.UserEntity;
import com.auth.proxy.UserProxy;
import com.auth.service.EmailService;
import com.auth.service.UserService;

@RestController
@RequestMapping("/auth")
public class UserController {
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private EmailService emailService;
	
	@PostMapping("/saveUser") //working [created at-23-03-2025]
	//@PreAuthorize(value = "hasRole('ROLE_ADMIN')")
	public String saveUser(@RequestBody UserProxy user)
	{
		userService.save(user);
		return "saved";
	}
	
	@PostMapping("/generate")
	public String generateTocken(@RequestBody UserEntity emp)
	{
		return  userService.generateTocken(emp);
	}
	
	@PostMapping("/loginReq") //working 
	public LoginResponse login(@RequestBody LoginRequest loginRequest)
	{
		System.out.println(loginRequest.getPassword()+"\n"+loginRequest.getUserName());
		return userService.login(loginRequest);
	}
	
	  @PostMapping("/sendMail")
	    public String
	    sendMail(@RequestBody EmailDetails details,Model model)
	    {
	    	Model m=model.addAttribute("r",details.getRecipient());
	    	System.out.println("m:"+m);
	        String status
	            = emailService.sendSimpleMail(details);
	        return status;
	    }
}
