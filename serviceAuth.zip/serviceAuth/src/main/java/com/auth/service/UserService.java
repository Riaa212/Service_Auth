package com.auth.service;

import com.auth.domain.LoginRequest;
import com.auth.domain.LoginResponse;
import com.auth.domain.UserEntity;
import com.auth.proxy.UserProxy;

public interface UserService {

	public String save(UserProxy emp);
	
	//generate jwt tocken
	public String generateTocken(UserEntity user);
	
	//login
	public LoginResponse login(LoginRequest loginRequest);
	
}
