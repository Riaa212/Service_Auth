package com.auth.service;

import com.auth.domain.EmailDetails;

public interface EmailService {

	//send simple mail
			String sendSimpleMail(EmailDetails details);
		 
		    // Method
		    // To send an email with attachment
		    String sendMailWithAttachment(EmailDetails details);	    
}
