package com.auth.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.auth.config.JwtService;
import com.auth.domain.LoginRequest;
import com.auth.domain.LoginResponse;
import com.auth.domain.UserEntity;
import com.auth.proxy.UserProxy;
import com.auth.repository.UserRepo;
import com.auth.service.UserService;
import com.auth.utils.Helper;

@Service
public class UserServiceImpl implements UserService
{

	@Autowired
	private UserRepo userRepo;
	
	@Autowired
	private Helper helper;
	
	@Autowired
	private AuthenticationManager authmanager;
	
	@Autowired
	private BCryptPasswordEncoder passwordEncoder;
	
	@Autowired
	private JwtService jwtService;
	
	@Override
	public String save(UserProxy user) {
		user.setPassword(passwordEncoder.encode(user.getPassword()));
		userRepo.save(helper.convert(user, UserEntity.class));
		return "Saved successfully";
	}

	@Override
	public String generateTocken(UserEntity user) {
		UserEntity findByUserName = userRepo.findByUserName(user.getUserName());

		System.out.println(findByUserName);
		System.out.println(findByUserName.getPassword());
		//System.out.println(emp.getPassword());
		boolean matches = passwordEncoder.matches(user.getPassword(),findByUserName.getPassword());
		
		System.out.println("Matches Password:"+matches);
		if(!matches)
		{
		return "user not found";
		}
		return jwtService.genearteTocken(user.getUserName());
	}

	@Override
	public LoginResponse login(LoginRequest loginRequest) {
		System.out.println("login response from emp service called..");
		Authentication authentication=new UsernamePasswordAuthenticationToken(loginRequest.getUserName(), loginRequest.getPassword());
		
		Authentication verified = authmanager.authenticate(authentication);
		
		if(!verified.isAuthenticated())
		{
			//System.out.println("user not found");
			//System.err.println("user not found");
			//throw new BadCredicialException(null, null);
			//throw new BadCredentialsException("Bad credentials...");
			System.out.println("bad credials..");
			//throw new ErrorResponse("bad credentials",404);
		}
		
		 return new LoginResponse(loginRequest.getUserName(),jwtService.genearteTocken(loginRequest.getUserName()),(List<SimpleGrantedAuthority>) verified.getAuthorities());	 
	}

	public String resetPassword(String oldPwd,String newPwd)
	{ 
		userRepo.findByPasswordAndUserName(oldPwd, newPwd);
		return null;
	}
	
	public String forgetPassword()
	{
		return null;
	}
}
