package com.auth.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.auth.domain.UserEntity;
import java.util.List;



public interface UserRepo extends JpaRepository<UserEntity, Integer>
{
	UserEntity findByUserName(String userName);
	
	List<UserEntity> findByPasswordAndUserName(String password,String username);
	
}
